import java.util.*;

public class SpatialHashGrid{
    private final int cellSize;

    private final Map<String, List<Entity>> grid = new HashMap<>();

    public SpatialHashGrid(int cellSize){
        this.cellSize = cellSize;
    }
    public void clear(){
        grid.clear();
    }
    private String getKey(float x, float y){
        int cellX = (int)Math.floor(x / cellSize);
        int cellY = (int)Math.floor(y / cellSize);
        return cellX + ", " + cellY;
    }
    public void insert(float x, float y, Entity entity){
        String key = getKey(x, y);
        grid.computeIfAbsent(key, k -> new ArrayList<>()).add(entity);
    }
    public List<Entity> getNearby(float x, float y, float radius){
        List<Entity> nearby = new ArrayList<>();
        int minCx = (int) Math.floor((x - radius) / cellSize);
        int maxCx = (int) Math.floor((x + radius) / cellSize);
        int minCy = (int) Math.floor((y - radius) / cellSize);
        int maxCy = (int) Math.floor((y + radius) / cellSize);

        int cellX = (int)Math.floor(x / cellSize);
        int cellY = (int)Math.floor(y / cellSize);

        for(int i = minCx; i <= maxCx; i++){
            for(int j = minCy; j <= maxCy; j++){
                String key = i + ", " + j;
                List<Entity> cellEntitys = grid.get(key);
                if(cellEntitys != null) nearby.addAll(cellEntitys);
            }
        }
        return nearby;
    }
}