import java.awt.*;
import java.awt.geom.*;
import java.util.List;
import java.util.Random;

public class Virus extends Entity{

    public static final long DEFAULT_SIZE = 100;
    private static final Color FILL_COLOR = new Color(51, 255, 51);
    private static final Color OUTLINE_COLOR = new Color(0, 0, 0, 50);

    /** 給餌された回数。VIRUS_FEED_TO_SPLIT回で分裂する */
    public int feedCount = 0;
    /** 最後に給餌されてきた方向(分裂時に新しいウイルスを飛ばす向きに使う) */
    public Vector2D lastFeedDir = new Vector2D(1, 0);

    // 給餌で成長する(=半径が変わる)ようになったため、トゲトゲの形はもう全個体共通の
    // staticキャッシュにはできない。ただし「半径が変わった時だけ作り直す」ようにして、
    // 毎フレーム作り直すのは避ける。
    private Shape needleShape;
    private float shapeBuiltAtRadius = -1;

    public Virus(Vector2D pos){
        // Entityのposを共有せず自分専用のVector2Dを持たせる(reset()で使い回すため)
        super(pos);
        this.size = DEFAULT_SIZE;
        setRadius();
        rebuildShapeIfNeeded();
    }
    public Virus(float x, float y){
        this(new Vector2D(x, y));
    }
    /** プールから取り出した古いVirusインスタンスを新しい位置・既定サイズで作り直す */
    public void reset(float x, float y){
        this.pos.x = x;
        this.pos.y = y;
        this.vel.x = 0;
        this.vel.y = 0;
        this.size = DEFAULT_SIZE;
        setRadius();
        this.alive = true;
        this.feedCount = 0;
        rebuildShapeIfNeeded();
    }
    /**
     * 質量投げで給餌される。少しだけ成長し、給餌回数を1増やす。
     * VIRUS_FEED_TO_SPLIT回に達したら true を返すので、呼び出し側で分裂させる。
     */
    public boolean feed(long amount, Vector2D fromDir){
        this.size += amount;
        setRadius();
        rebuildShapeIfNeeded();
        feedCount++;
        if(fromDir.lengthSq() > 0){
            lastFeedDir = fromDir.normalize();
        }
        return feedCount >= Constants.VIRUS_FEED_TO_SPLIT;
    }
    /** 分裂した後、自分自身は既定サイズに戻る(新しく分身が1体飛んでいく) */
    public void resetAfterSplit(){
        this.size = DEFAULT_SIZE;
        setRadius();
        this.feedCount = 0;
        rebuildShapeIfNeeded();
    }
    /** 分裂で飛び出した直後は速度を持っているので、摩擦をかけながら移動させる */
    public void update(double deltaTime){
        if(vel.lengthSq() > 0.01f){
            pos.x += vel.x;
            pos.y += vel.y;
            vel.x *= 0.9f;
            vel.y *= 0.9f;
            if(vel.lengthSq() < 1){ vel.x = 0; vel.y = 0; }
        }
        pos.x = Math.max(radius, Math.min(pos.x, Constants.MAP_WIDTH  - radius));
        pos.y = Math.max(radius, Math.min(pos.y, Constants.MAP_HEIGHT - radius));
    }
    private void rebuildShapeIfNeeded(){
        if(needleShape == null || shapeBuiltAtRadius != radius){
            needleShape = buildNeedle(radius);
            shapeBuiltAtRadius = radius;
        }
    }
    public void draw(Graphics2D g2d, Camera cam){
        rebuildShapeIfNeeded();

        float sx = cam.worldToScreenX(pos.x);
        float sy = cam.worldToScreenY(pos.y);
        float sr = radius * cam.zoom;

        // needleShapeはワールド座標系(半径そのまま、中心が原点)で作ってあるので、
        // 描画時に画面上の位置へ平行移動＋ズーム倍率で拡大縮小する。
        // (以前はこの変換が無く、ウイルスは常にバッファ左上に固定表示されるバグがあった)
        AffineTransform old = g2d.getTransform();
        g2d.translate(sx, sy);
        g2d.rotate(angle);
        g2d.scale(cam.zoom, cam.zoom);

        g2d.setColor(FILL_COLOR);
        g2d.fill(needleShape);
        g2d.setColor(OUTLINE_COLOR);
        g2d.setStroke(Constants.DEFAULT_STROKE);
        g2d.draw(needleShape);

        g2d.setTransform(old);
    }
    private static Shape buildNeedle(float r){
        Path2D path = new Path2D.Float();
        path.moveTo(r, 0);
        for(int i = 1 ; i < 72; i++){
            float a = (float)Math.toRadians(i * 5);
            if(i % 2 == 0) path.lineTo(r * (float)Math.cos(a), r * (float)Math.sin(a));
            else path.lineTo(r * 0.9f * (float)Math.cos(a), r * 0.9f * (float)Math.sin(a));
        }
        path.closePath();
        return path;
    }
}
