public class Camera{
    public float x, y;
    public float zoom;

    public Camera(){
        x = 0; y = 0; zoom = 1.0f;
    }

    public void centerOn(float wx, float wy){
        x = wx - Constants.SCREEN_WIDTH / 2f / zoom;
        y = wy - Constants.SCREEN_HEIGHT / 2f / zoom;
    }

    public float getX(){ return x; }
    public float getY(){ return y; }

    public float worldToScreenX(float wx){ return (wx - x) * zoom; }
    public float worldToScreenY(float wy){ return (wy - y) * zoom; }
    public float screenToWorldX(float sx){ return sx / zoom + x; }
    public float screenToWorldY(float sy){ return sy / zoom + y; }
}
