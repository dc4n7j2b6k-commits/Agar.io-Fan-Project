import javax.swing.*;
import javax.swing.Timer;
import java.awt.*;
import java.awt.font.*;
import java.awt.event.*;
import java.awt.image.*;
import java.awt.geom.*;
import java.math.*;
import java.util.*;
import java.util.List;
import java.io.File;
import javax.imageio.ImageIO;

public class AgarIOMap extends JPanel implements ActionListener, MouseMotionListener{

    // ── 特殊モード ───────────────────────────────────────────────────
    private static final long DAY_SECONDS = 86400L;
    private static final long NANOS_PER_SRC = 1_000_000_000L;
    private static final long MAX_TIME = DAY_SECONDS * NANOS_PER_SRC;
    private Timer timer;
    private long lastTime;
    private long lastFpsTime;
    public static long globalTime = 0;
    private double deltaTime = 0;
    private Player player;
    private Camera camera;
    private HUD hud;

    private Random rand = new Random();
    private float mouseWorldX, mouseWorldY, mouseScreenX, mouseScreenY;
    private BufferedImage buffer;

    public static float CX, CY;

    private int fps, frames;
    private final Bot[] bots = new Bot[Constants.MAX_BOTS];
    private final Cell[] allCells = new Cell[Constants.MAX_CELLS];
    private final Food[] foods = new Food[Constants.MAX_FOODS];
    private final Virus[] viruses = new Virus[Constants.MAX_VIRUSES];

    private Set<Integer> press = new HashSet<>();
    private BufferedImage[] texture;
    private long[] teamSize = {0, 0, 0, 0};
    private boolean teamMode = false;
    private int colorMax = 1;
    private JButton respawnButton = new JButton("復活");
    private JButton giveupButton = new JButton("終わる");

    private CollsionResolver collsionResolver;
    private final SpatialHashGrid spatialHash = new SpatialHashGrid(200);

    public AgarIOMap(CardLayout card, JPanel parent){
        setLayout(null);
        setDoubleBuffered(true);
        setPreferredSize(new Dimension(Constants.SCREEN_WIDTH, Constants.SCREEN_HEIGHT));
        setBackground(Color.LIGHT_GRAY);
        setFocusable(true);
        addMouseMotionListener(this);
        buffer = new BufferedImage(Constants.SCREEN_WIDTH, Constants.SCREEN_HEIGHT, BufferedImage.TYPE_INT_ARGB);
        hud = new HUD();
        Constants.initMapSize();
        // キーｲﾍﾞﾝﾄ
        registerKey("W", KeyEvent.VK_W);
        registerKey("SPACE", KeyEvent.VK_SPACE);
        try{
            texture = new BufferedImage[] {
                null
            };
        }catch(Exception e){
            e.printStackTrace();
        }
        respawnButton.setBackground(Color.RED);
        respawnButton.setForeground(Color.WHITE);
        respawnButton.setBorderPainted(false);
        respawnButton.setFont(new Font("SansSerif", Font.BOLD, 25));
        respawnButton.addActionListener(e -> {
            if(timer.isRunning() && player != null && !player.alive){
                requestFocusInWindow();
                player.reset(rand.nextFloat() * Constants.MAP_WIDTH, rand.nextFloat() * Constants.MAP_HEIGHT, player.teamId);
            }
        });
        add(respawnButton);
        giveupButton.setBackground(Color.WHITE);
        giveupButton.setForeground(Color.DARK_GRAY);
        giveupButton.setBorderPainted(false);
        giveupButton.setFont(new Font("SansSerif", Font.BOLD, 25));
        giveupButton.addActionListener(e -> {
            if(timer.isRunning() && player != null && !player.alive){
                timer.stop();
                for(Cell cell : allCells) cell.destroy();
                for(Food food : foods) food.destroy();
                for(Virus virus : viruses) virus.alive = false;
                for(Bot bt : bots) bt.alive = false;
                
                for(int i = 0; i < teamSize.length; i++) teamSize[i] = 0;
                card.show(parent, "menu");
            }
        });
        add(giveupButton);
        timer = new Timer(1000 / Constants.TARGET_FPS, this);
    }
    public void onShow(String mode, String playerName){
        lastTime = lastFpsTime = System.nanoTime();
        teamMode = mode.contains("Teams");
        for(int i = 2; i < 5; i++){
            if(mode.contains(String.valueOf(i))){
                colorMax = i;
                break;
            }
        }
        CX = Constants.MAP_WIDTH / 2;
        CY = Constants.MAP_HEIGHT / 2;

        timer.start();
        camera = new Camera(); camera.zoom = 1f;
        collsionResolver = new CollsionResolver(allCells, teamMode);

        int index = -1;
        if(teamMode)
            index = rand.nextInt(colorMax);

        player = new Player(new Vector2D(CX, CY), Constants.INITIAL_SIZE, index);

        player.setName(playerName);
        spawnEntity();
    }
    private void spawnEntity(){
        for(int i = 0; i < bots.length; i++){
            int teamId = teamMode ? getMinTeam() : -1;
            Bot bot = bots[i];
            if(bot == null){
                bots[i] = new Bot(new Vector2D(rand.nextFloat() * Constants.MAP_WIDTH, rand.nextFloat() * Constants.MAP_HEIGHT), Constants.INITIAL_SIZE, teamId);
            }else if(!bot.alive){
                bot.reset(rand.nextFloat() * Constants.MAP_WIDTH, rand.nextFloat() * Constants.MAP_HEIGHT, teamId);
            }
            setBigSize();
        }
        for(int i = 0; i < foods.length; i++){
            Food food = foods[i];
            if(food == null){
                foods[i] = new Food(rand.nextFloat() * Constants.MAP_WIDTH, rand.nextFloat() * Constants.MAP_HEIGHT, null);
            }else if(!food.alive){
                food.setPosition(rand.nextFloat() * Constants.MAP_WIDTH, rand.nextFloat() * Constants.MAP_HEIGHT, 1, null);
            }
        }
        for(int i = 0; i < viruses.length; i++){
            Virus virus = viruses[i];
            if(virus == null){
                viruses[i] = new Virus(rand.nextFloat() * Constants.MAP_WIDTH, rand.nextFloat() * Constants.MAP_HEIGHT);
            }else if(!virus.alive){
                virus.reset(rand.nextFloat() * Constants.MAP_WIDTH, rand.nextFloat() * Constants.MAP_HEIGHT);
            }
        }
    }
    @Override
    public void actionPerformed(ActionEvent e){
        update();
        render();
        repaint();
    }
    private void update(){
        frames++;
        mouseWorldX = camera.screenToWorldX(mouseScreenX);
        mouseWorldY = camera.screenToWorldY(mouseScreenY);

        long now = System.nanoTime();
        long deltaNano = now - lastTime;
        lastTime = now;
        deltaTime = deltaNano / (double)NANOS_PER_SRC;
        globalTime = (globalTime + deltaNano) % MAX_TIME;

        if(now - lastFpsTime >= NANOS_PER_SRC){
            fps = frames;
            frames = 0;
            lastFpsTime = now;
        }

        camera.centerOn(player.pos.x, player.pos.y);
        camera.zoom += (player.targetCameraZoom - camera.zoom) * 0.1f;
        if(!player.alive){
            respawnButton.setBounds(Constants.SCREEN_WIDTH / 2 + 25, Constants.SCREEN_HEIGHT * 2 / 3, 150, 75);
            giveupButton.setBounds(Constants.SCREEN_WIDTH / 2 - 175, Constants.SCREEN_HEIGHT * 2 / 3, 150, 75);
        }else{
            respawnButton.setBounds(Constants.SCREEN_WIDTH, Constants.SCREEN_HEIGHT, 200, 100);
            giveupButton.setBounds(Constants.SCREEN_WIDTH, Constants.SCREEN_HEIGHT, 200, 100);
        }
        spatialHash.clear();
        if(player.alive){
            player.updateViewRange();
            player.update(deltaTime, mouseWorldX, mouseWorldY, isKeyPressed(KeyEvent.VK_SPACE), isKeyPressed(KeyEvent.VK_W), foods);
        }
        setAllCells();
        for(Food food : foods){
            if(!food.alive) continue;
            spatialHash.insert(food.pos.x, food.pos.y, food);
            food.update(deltaTime);
        }
        for(Virus virus : viruses){
            if(!virus.alive) continue;
            spatialHash.insert(virus.pos.x, virus.pos.y, virus);
        }
        for(Cell cell : allCells){
            if(!cell.alive) continue;
            cell.update(deltaTime);
            spatialHash.insert(cell.pos.x, cell.pos.y, cell);
        }
        for(Bot bt : bots){
            if(!bt.alive) continue;
            bt.updateViewRange();
            bt.update(deltaTime, spatialHash, foods);
        }
        collsionResolver.resolveAll(spatialHash);

        spawnEntity();
    }
    private void setAllCells(){
        int idx = 0;
        for(; idx < player.cells.length; idx++){
            allCells[idx] = player.cells[idx];
        }
        for(int i = 0; i < bots.length; i++){
            Bot bot = bots[i];
            for(int j = 0; j < bot.cells.length; j++, idx++){
                allCells[idx] = bot.cells[j];
            }
        }
        Arrays.sort(allCells, Comparator.comparingLong(Cell::getSize));
    }
    protected void paintComponent(Graphics g){
        super.paintComponent(g);
        g.drawImage(buffer, 0, 0, null);
        Toolkit.getDefaultToolkit().sync();
    }
    private void render(){
        Graphics2D g2d = buffer.createGraphics();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_SPEED);
        g2d.setColor(Constants.BG_COLOR);
        g2d.fillRect(0, 0, Constants.SCREEN_WIDTH, Constants.SCREEN_HEIGHT);
        g2d.setColor(new Color(0, 0, 0, 0.1f));
        g2d.fillRect(0, 0, Constants.SCREEN_WIDTH, Constants.SCREEN_HEIGHT);

        if(camera != null){
            drawGrid(g2d);
            drawMap(g2d);
        }
        if(!player.alive) hud.drawGameOver(g2d, player);
        hud.draw(g2d, player, bots, teamSize, teamMode, fps);
        g2d.dispose();
    }
    private void drawMap(Graphics2D g2d){
        float minWorldX = camera.x;
        float minWorldY = camera.y;
        float maxWorldX = camera.x + Constants.SCREEN_WIDTH / camera.zoom;
        float maxWorldY = camera.y + Constants.SCREEN_HEIGHT / camera.zoom;

        List<Entity> list = spatialHash.getNearby(player.pos.x, player.pos.y, player.viewRangeWorld);
        list.sort(Comparator.comparingLong(Entity::getSize));
        for(Entity entity : list){
            if(!entity.alive) continue;
            if(entity.pos.x + entity.radius < minWorldX || entity.pos.x - entity.radius > maxWorldX ||
               entity.pos.y + entity.radius < minWorldY || entity.pos.y - entity.radius > maxWorldY){
                continue;
            }
            entity.draw(g2d, camera);
        }
    }
    private void drawGrid(Graphics2D g2d){
        float bx1 = camera.worldToScreenX(0);
        float by1 = camera.worldToScreenY(0);
        float bx2 = camera.worldToScreenX(Constants.MAP_WIDTH);
        float by2 = camera.worldToScreenY(Constants.MAP_HEIGHT);

        g2d.setColor(Constants.BG_COLOR);
        g2d.fill(new Rectangle2D.Float(bx1, by1, bx2 - bx1, by2 - by1));
        g2d.setColor(Constants.GRID_COLOR);
        g2d.setStroke(Constants.DEFAULT_STROKE);

        g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.5f));

        float gridSize = Constants.GRID_SIZE * camera.zoom;

        float minWorldX = camera.x;
        float minWorldY = camera.y;
        float maxWorldX = camera.x + Constants.SCREEN_WIDTH / camera.zoom;
        float maxWorldY = camera.y + Constants.SCREEN_HEIGHT / camera.zoom;

        for(float x = bx1; x <= bx2; x += gridSize){
            if(x < 0 || x > Constants.SCREEN_WIDTH) continue;
            g2d.draw(new Line2D.Float(x, 0, x, Constants.SCREEN_HEIGHT));
        }

        for(float y = by1; y <= by2; y += gridSize){
            if(y < 0 || y > Constants.SCREEN_HEIGHT) continue;
            g2d.draw(new Line2D.Float(0, y, Constants.SCREEN_WIDTH, y));
        }

        g2d.setColor(new Color(0x777777));
        g2d.setStroke(new BasicStroke(3f));
        g2d.draw(new Rectangle2D.Float(bx1, by1, bx2 - bx1, by2 - by1));

        g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));
    }
    private void setBigSize(){
        List<Player> list = new ArrayList<>();
        if(player.alive) list.add(player);
        for(Bot bt : bots) if(bt != null && bt.alive) list.add(bt);
        for(long total : teamSize) total = 0;
        for(Player p : list){
            long total = p.size;
            for(int i = 0; i < colorMax; i++){
                if(p.teamId == i) teamSize[i] += total;
            }
        }
    }
    private int getMinTeam(){
        int weakestTeam = 0;
        long minTeam = teamSize[0];
        for(int i = 1; i < colorMax; i++){
            if(teamSize[i] < minTeam){
                minTeam = teamSize[i];
                weakestTeam = i;
            }
        }
        return weakestTeam;
    }
    public boolean isKeyPressed(int keyCode){
        return press.contains(keyCode);
    }
    @Override public void mouseDragged(MouseEvent e){}
    @Override
    public void mouseMoved(MouseEvent e){
        mouseScreenX = e.getX();
        mouseScreenY = e.getY();
    }
    private void registerKey(String keyString, int keyCode){
        bindKeyAction(keyString, false, () -> press.add(keyCode));
        bindKeyAction(keyString, true, () -> press.remove(keyCode));
    }
    private void bindKeyAction(String key, boolean onRelease, Runnable action){
        InputMap inMap = getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
        ActionMap acMap = getActionMap();

        KeyStroke keyStroke = KeyStroke.getKeyStroke(key);
        if(onRelease){
            keyStroke = KeyStroke.getKeyStroke("released " + key);
        }
        String mapKey = key + (onRelease ? "_released" : "_pressed");
        inMap.put(keyStroke, mapKey);
        acMap.put(mapKey, new AbstractAction(){
            public void actionPerformed(ActionEvent e){
                if(action != null){
                    action.run();
                }
            }
        });
    }
}