import java.awt.*;
import java.util.*;
import java.util.List;

public class Constants{
    public static final int SCREEN_WIDTH  = 1360;
    public static final int SCREEN_HEIGHT = 765; // viewRange=750.42
    public static final int WORLD_WIDTH   = 20000;
    public static final int WORLD_HEIGHT  = 20000;
    public static float MAP_WIDTH;
    public static float MAP_HEIGHT;
    public static final int TARGET_FPS    = 60;
    public static final int GRID_SIZE     = 50;

    /** 日本語対応フォント。システムに応じて自動選択 */
    public static final String FONT_NAME = resolveFont();
    private static String resolveFont() {
        // 日本語フォント優先候補
        String[] candidates = {"Yu Gothic", "Meiryo", "MS Gothic",
                               "Hiragino Kaku Gothic Pro", "Noto Sans CJK JP",
                               "SansSerif", "Serif"};
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        Set<String> available = new HashSet<>(Arrays.asList(ge.getAvailableFontFamilyNames()));
        for(String f : candidates) if(available.contains(f)) return f;
        return "SansSerif"; // フォールバック
    }
    public static void initMapSize(){
        MAP_WIDTH = WORLD_WIDTH;
        MAP_HEIGHT = WORLD_HEIGHT;
    }
    public static void setMapSize(float factor){
        MAP_WIDTH = (float)WORLD_WIDTH * factor;
        MAP_HEIGHT = (float)WORLD_HEIGHT * factor;
    }

    public static final long INITIAL_SIZE = 500;
    public static final BasicStroke DEFAULT_STROKE = new BasicStroke(1.0f);

    // ── Colors ─────────────────────────────────────────────────────────────
    public static final Color BG_COLOR          = new Color(0xCDCDCD);
    public static final Color GRID_COLOR        = new Color(0xC0C0C0);

    // ── Player base ────────────────────────────────────────────────────────
    public static final float PLAYER_RADIUS   = 20f;
    public static final float PLAYER_SPEED    = 0.5f;

    /** スポーン後の無敵フレーム数（10秒 = 600f） */
    public static final float SPAWN_INVINCIBLE_SECONDS = 10;

    // ── セル分裂 ───────────────────────────────────────────────────────────
    /** プレイヤー(Bot含む)1人が同時に持てるセルの最大数 */
    public static final int MAX_PLAYER_CELLS = 8;
    /** セル1つの最大サイズ */
    public static final long MAX_CELL_SIZE = 22500;
    /** これ未満のサイズのセルは分裂できない(半分にしても小さすぎるため) */
    public static final long MIN_SPLIT_SIZE = 100;
    /** 分裂/合体クールダウン秒数。この間は再分裂も同じ相手との合体もできない */
    public static final float SPLIT_COOLDOWN_SECONDS = 30f;
    /** 分裂した小セルが飛び出す初速 */
    public static final float SPLIT_BOOST_SPEED = 5f;
    /** 敵セルを食べるのに必要な倍率(自分がこれだけ大きくないと食べられない) */
    public static final float CELL_EAT_RATIO = 1.25f;

    // ── 質量射出(Wキーで餌やり) ───────────────────────────────────────────
    /** Wキー1回で失う質量 */
    public static final long FEED_COST = 18;
    public static final long FEED_FOOD = 16;
    /** これ未満のサイズのセルは餌やりできない */
    public static final long MIN_FEED_SIZE = 60;
    /** 射出される質量の初速 */
    public static final float FEED_EJECT_SPEED = 24f;

    // ── ウイルス ───────────────────────────────────────────────────────────
    /** ウイルスに給餌して分裂させるのに必要な回数(目安7回) */
    public static final int VIRUS_FEED_TO_SPLIT = 7;
    /** 分裂して飛んでいく新しいウイルスの初速 */
    public static final float VIRUS_EJECT_SPEED = 20f;

    // ── Spawn counts ───────────────────────────────────────────────────────
    public static final int MAX_FOODS    = 2500;
    public static final int MAX_VIRUSES  = 225;
    public static final int MAX_BOTS     = 200;
    public static final int MAX_CELLS    = (1 + MAX_BOTS) * MAX_PLAYER_CELLS;
}
