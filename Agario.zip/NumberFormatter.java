public class NumberFormatter{
    public static String formatSize(double size){
        String[] units = {"", "K", "M", "B", "T", "P", "E"};
        int index = 0;
        while(size >= 1000 && index < units.length - 1){
            size /= 1000;
            index++;
        }
        return (index == 0) ? ""+(long)size : String.format("%.1f%s", size, units[index]);
    }
}