import java.awt.*;
import java.awt.geom.*;
import java.util.*;
import java.util.List;

public abstract class Entity{
    public Vector2D pos, vel;
    public float angle = 0;
    public long score = 0;
    public long size = 0;
    public float spawnInvincible = 0;
    public float viewRangeWorld = 0;
    public boolean alive = true;
    public Color bodyColor, outlineColor;
    protected String name = "";
    public float radius;
    public int kills;

    public boolean respawn = true;
    public float respawnTime = 3f;

    // ── 内部 ──────────────────────────────────────────────────────────────
    public int teamId = -1;
    public float targetCameraZoom = 1.0f;

    protected static final Random rand = new Random();

    public Entity(float x, float y){
        this.pos = new Vector2D(x, y);
        this.vel = new Vector2D(0, 0);
        this.angle = rand.nextFloat() * (float)Math.PI * 2;
    }
    public Entity(Vector2D pos){
        this.pos = pos;
        this.vel = new Vector2D(0, 0);
        this.angle = rand.nextFloat() * (float)Math.PI * 2;
    }
    public boolean isInvincible(){
        return spawnInvincible > 0;
    }
    /** タンクのviewZoom をそのままカメラターゲットにする */
    protected void updateTargetZoom(){
        setRadius();
        if(radius <= 0){
            targetCameraZoom = 1.0f;
            return;
        }
        targetCameraZoom = 100f / radius;
    }
    protected void setRadius(){
        radius = (float) Math.sqrt(size * 25);
    }
    /** カメラのzoom相当を使ってBotの視野範囲を更新する */
    public void updateViewRange(){
        updateTargetZoom();
        // スクリーン半幅をワールド座標に換算
        float halfW = Constants.SCREEN_WIDTH  / 2f / targetCameraZoom;
        float halfH = Constants.SCREEN_HEIGHT / 2f / targetCameraZoom;
        viewRangeWorld = (float)Math.sqrt(halfW*halfW + halfH*halfH);
    }
    public void draw(Graphics2D g2d, Camera cam){}

    public long getSize(){
        return size;
    }
    public Color getColor(){
        int hashCode = this.hashCode();
        int positiveHash = hashCode & 0x7FFFFFFF;
        float hue = (float) positiveHash / Integer.MAX_VALUE;
        return Color.getHSBColor(hue, 1.0f, 1.0f);
    }
    public static final Color[] TEAM_COLORS = {
        Color.BLUE, Color.GREEN, Color.RED, Color.YELLOW
    };
    public static final Color[] TEAM_OUTLINES = {
        TEAM_COLORS[0].darker(),
        TEAM_COLORS[1].darker(),
        TEAM_COLORS[2].darker(),
        TEAM_COLORS[3].darker()
    };
}