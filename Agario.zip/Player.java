import java.awt.*;
import java.awt.geom.*;
import java.awt.image.*;
import java.util.*;
import java.util.List;

public class Player extends Entity{
    public long bestScore = 0;
    public Cell[] cells = new Cell[Constants.MAX_PLAYER_CELLS];
    protected boolean lastSpaceState = false;
    protected boolean lastWState = false;

    public Player(Vector2D pos, long size, int teamId){
        super(pos);
        this.size = size;
        this.teamId = teamId;
        bodyColor = getBodyColor();
        outlineColor = getOutlineColor();
        init();
    }
    // 名前を設定する
    public void setName(String name){
        this.name = name;
    }
    public void setTeamId(int id){
        this.teamId = teamId;
    }
    public void reset(float x, float y, int teamId){
        this.pos.x = x;
        this.pos.y = y;
        this.vel.x = 0;
        this.vel.y = 0;
        this.size = Constants.INITIAL_SIZE;
        this.teamId = teamId;
        bodyColor = getBodyColor();
        outlineColor = getOutlineColor();
        this.alive = true;
        setRadius();
        init();
    }
    protected void init(){
        for(int i = 0; i < cells.length; i++){
            Cell cell = null;
            if(i == 0)
                cell = new Cell(this, pos, size);
            else
                cell = new Cell(this);
            cells[i] = cell;
        }
        this.pos.x = cells[0].pos.x;
        this.pos.y = cells[0].pos.y;
        updateViewRange();
    }
    public void update(double deltaTime, float mouseX, float mouseY, boolean spacePressed, boolean wPressed, Food[] foods){
        if(!alive) return;
        if(spawnInvincible > 0) spawnInvincible -= deltaTime;

        if(size > bestScore) bestScore = size;
        sum();

        angle = (float)Math.atan2(mouseY - pos.y, mouseX - pos.x);

        splitCell(mouseX, mouseY, spacePressed);
        throwMass(mouseX, mouseY, wPressed, foods);
        
        move(mouseX, mouseY);
    }
    // プレイヤー全体を移動させる
    public void move(float mouseX, float mouseY){
        float nx = 0, ny = 0;
        int count = 0;
        for(Cell cell : cells){
            if(!cell.alive) continue;
            float a = (float)Math.atan2(mouseY - cell.pos.y, mouseX - cell.pos.x);
            cell.move(a, mouseX, mouseY);
            nx += cell.pos.x;
            ny += cell.pos.y;
            count++;
        }
        if(count == 0) return; 
        pos.x = nx / count;
        pos.y = ny / count;
    }
    public void splitCell(float mouseX, float mouseY, boolean pressed){
        if(pressed && !lastSpaceState){
            List<Cell> targetCells = new ArrayList<>();
            for(Cell cell : cells){
                if(cell.alive && cell.size >= Constants.MIN_SPLIT_SIZE){
                    targetCells.add(cell);
                }
            }
            for(Cell parent : targetCells){
                splitTowards(parent, mouseX, mouseY);
            }
        }
        lastSpaceState = pressed;
    }
    protected void splitTowards(Cell parentCell, float targetX, float targetY){
        int count = 0;
        for(Cell cell : cells){
            if(cell.alive) count++;
        }
        if(count >= Constants.MAX_PLAYER_CELLS) return;
        if(parentCell.size > Constants.MIN_SPLIT_SIZE){
            int emptyIndex = -1;
            for(int i = 0; i < cells.length; i++){
                if(!cells[i].alive){
                    emptyIndex = i;
                    break;
                }
            }
            if(emptyIndex == -1) return;
            float a = (float)Math.atan2(targetY - parentCell.pos.y, targetX - parentCell.pos.x);
            float initialSpeed = parentCell.radius / 2;
            long newSize = parentCell.size / 2;
            parentCell.size = newSize;

            Cell ejected = cells[emptyIndex];
            ejected.spawn(parentCell.pos, newSize);
            ejected.vel.x = initialSpeed * (float)Math.cos(a);
            ejected.vel.y = initialSpeed * (float)Math.sin(a);
        }
    }
    // 質量投げ：自分のセルからマスを投げる
    public void throwMass(float mouseX, float mouseY, boolean pressed, Food[] foods){
        if(pressed && !lastWState){
            for(Cell cell : cells){
                if(cell.alive && cell.size > Constants.MIN_FEED_SIZE){
                    throwEjectedMass(mouseX, mouseY, cell, foods);
                }
            }
        }
        lastWState = pressed;
    }
    protected void throwEjectedMass(float targetX, float targetY, Cell mine, Food[] foods){
        float a = (float)Math.atan2(targetY - mine.pos.y, targetX - mine.pos.x);

        mine.size -= Constants.FEED_COST;
        long newSize = Constants.FEED_FOOD;

        int emptyIndex = -1;
        for(int i = 0; i < foods.length; i++){
            if(!foods[i].alive){
                emptyIndex = i; break;
            }
        }
        if(emptyIndex < 0){
            emptyIndex = (int)(Math.random() * foods.length);
        }
        Food mass = foods[emptyIndex];
        mass.setPosition(mine.pos.x, mine.pos.y, newSize, bodyColor);
        mass.invincibleTimer = 1f;
        mass.vel.x = mine.radius / 2 * (float)Math.cos(a);
        mass.vel.y = mine.radius / 2 * (float)Math.sin(a);
    }
    // 細胞が衝突した場合の処理(同じ持ち主のセル同士がまだ合体できない時に押し合う)
    public void separateCells(Cell ally, Cell cell){
        // ally : 他のセル cell : 自身のセル
        float dx = ally.pos.x - cell.pos.x;
        float dy = ally.pos.y - cell.pos.y;
        
        // 実際の中心間距離と、本来あるべき距離(半径の合計)
        float currentDist = (float)Math.sqrt(dx * dx + dy * dy);
        float targetDist = ally.radius + cell.radius;

        // 衝突していない、または完全に中心が重なっている場合は処理しない
        if(currentDist >= targetDist || currentDist < 0.1f) return;

        // めり込んでいる距離
        float overlap = targetDist - currentDist;

        // 押し出す方向の単位ベクトル (長さ1の方向)
        float nx = dx / currentDist;
        float ny = dy / currentDist;
        float pushForce = overlap * 0.15f;

        // --- サイズに応じた押し合いいの判定 ---
        if(cell.radius < ally.radius){
            // 1. 自身(cell)が小さい：自身だけが弾かれる
            cell.vel.x -= nx * pushForce;
            cell.vel.y -= ny * pushForce;
        }else if(cell.radius > ally.radius){
            // 2. 自身(cell)が大きい：相手(ally)だけを押し出す
            ally.vel.x += nx * pushForce;
            ally.vel.y += ny * pushForce;
        }else{
            // 3. 同じ大きさ：お互いに半分(0.5)ずつ押し合う！★ここがポイント
            float halfForce = overlap * 0.5f;

            cell.vel.x -= nx * halfForce;
            cell.vel.y -= ny * halfForce;

            ally.vel.x += nx * halfForce;
            ally.vel.y += ny * halfForce;
        }
    }
    public void sum(){
        long sum = 0;
        int aliveCount = 0;
        for(Cell cell : cells){
            if(!cell.alive) continue;
            sum += cell.size;
            aliveCount++;
        }
        this.size = sum;
        if(alive && aliveCount == 0){
            alive = false;
        }
    }
    public Color getBodyColor(){
        if(teamId >= 0){
            return TEAM_COLORS[teamId % TEAM_COLORS.length];
        }
        return getColor();
    }
    public Color getOutlineColor(){
        if(teamId >= 0){
            return TEAM_OUTLINES[teamId % TEAM_OUTLINES.length];
        }
        return getColor().darker();
    }
    public String toString(){
        return name;
    }
}