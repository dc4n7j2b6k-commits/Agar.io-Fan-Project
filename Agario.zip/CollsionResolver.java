import java.util.*;

public class CollsionResolver{
    private final Cell[] allCells;
    private final boolean teamMode;

    public CollsionResolver(Cell[] allCells, boolean teamMode){
        this.allCells = allCells;
        this.teamMode = teamMode;
    }
    public void resolveAll(SpatialHashGrid spatialHash){
        for(Cell cell : allCells){
            if(!cell.alive) continue;
            float cellRadius = cell.radius;
            float cellRadiusSq = cellRadius * cellRadius;
            float cellX = cell.pos.x;
            float cellY = cell.pos.y;
            List<Entity> nearbyEntitys = spatialHash.getNearby(cellX, cellY, cellRadius);
            if(nearbyEntitys.isEmpty()) return;
            for(Entity entity : nearbyEntitys){
                if(!entity.alive || cell == entity) continue;

                if(entity instanceof Food food){
                    if(food.invincibleTimer > 0) continue;
                    float foodX = food.pos.x;
                    float foodY = food.pos.y;
                    if(Math.abs(cellX - foodX) > cellRadius) continue;
                    if(Math.abs(cellY - foodY) > cellRadius) continue;

                    float dx = cellX - foodX;
                    float dy = cellY - foodY;
                    if((dx * dx) + (dy * dy) <= cellRadiusSq){
                        cell.eatFood(food.size);
                        food.alive = false;
                    }
                }else if(entity instanceof Virus virus){
                    if(!virus.alive || cell.size <= virus.size) continue;
                    float virusX = virus.pos.x;
                    float virusY = virus.pos.y;
                    if(Math.abs(cellX - virusX) > cellRadius) continue;
                    if(Math.abs(cellY - virusY) > cellRadius) continue;

                    float dx = cellX - virusX;
                    float dy = cellY - virusY;
                    float dist = (float)Math.sqrt(dx * dx + dy * dy);
                    if(dist > cellRadius + virus.radius) continue;
                    popSplit(cell.owner, cell, virus, dist);
                }else if(entity instanceof Cell other){
                    if(!other.alive) continue;
                    float otherX = other.pos.x;
                    float otherY = other.pos.y;
                    if(Math.abs(cellX - otherX) > cellRadius) continue;
                    if(Math.abs(cellY - otherY) > cellRadius) continue;

                    float dx = cell.pos.x - otherX;
                    float dy = cell.pos.y - otherY;
                    float dist = (float)Math.sqrt(dx * dx + dy * dy);

                    if(dist > cellRadius + other.radius) continue;

                    if(cell.owner == other.owner){
                        handleSameOwner(cell, other, dist);
                    }else if(teamMode && cell.teamId == other.teamId){
                        handleAlly(cell, other, dist);
                    }else{
                        handleEnemy(cell, other, dist);
                    }
                }
                if(!cell.alive) break;
            }
        }
    }
    private void popSplit(Player owner, Cell mine, Virus virus, float dist){
        int count = 0;
 
        for(Cell cell : owner.cells){
            if(cell.alive) count++;
        }

        int maxNewPieces = Constants.MAX_PLAYER_CELLS - count;
        if(maxNewPieces > 0){
            long totalPieces = maxNewPieces + 1L; // 元のセルも1つに数える
            long pieceSize = Math.max(1, mine.size / totalPieces);

            mine.size = Math.max(1, mine.size - pieceSize * maxNewPieces);
            mine.splitTimer = Constants.SPLIT_COOLDOWN_SECONDS;

            int c = 0;
            for(Cell cell : owner.cells){
                if(cell.alive || c >= maxNewPieces) continue;
                if(cell == mine) continue;
                int emptyIndex = -1;
                for(int i = 0; i < owner.cells.length; i++){
                    if(!owner.cells[i].alive){
                        emptyIndex = i; break;
                    }
                }
                if(emptyIndex == -1) break;

                float a = (float)(2 * Math.PI * c / maxNewPieces);
                float initialSpeed = mine.radius / 4;
                Cell piece = owner.cells[emptyIndex];
                piece.spawn(mine.pos, pieceSize);
                piece.vel.x = initialSpeed * (float)Math.cos(a);
                piece.vel.y = initialSpeed * (float)Math.sin(a);
                c++;
            }
        }else if(dist <= mine.radius){
            mine.size = Math.min(mine.size + virus.size, Constants.MAX_CELL_SIZE);
            virus.alive = false;
        }
    }
    private void handleSameOwner(Cell a, Cell b, float dist){
        boolean canMerge = a.splitTimer <= 0 && b.splitTimer <= 0;
        if(canMerge){
            // 合体：大きい方が小さい方を吸収して1つになる
            Cell bigger  = (a.size >= b.size) ? a : b;
            Cell smaller = (a.size >= b.size) ? b : a;
            if(dist > bigger.radius) return;
            bigger.size = Math.min(bigger.size + smaller.size, Constants.MAX_CELL_SIZE);
            smaller.destroy();
        }else if(a.splitTimer < Constants.SPLIT_COOLDOWN_SECONDS - 1 && b.splitTimer < Constants.SPLIT_COOLDOWN_SECONDS - 1){
            a.owner.separateCells(b, a);
        }
    }
    private void handleAlly(Cell a, Cell b, float dist){
        a.owner.separateCells(b, a);
    }
    private void handleEnemy(Cell a, Cell b, float dist){
        if(a.size == 0 || b.size == 0) return;
        Cell bigger, smaller;
        if(a.size > b.size){
            bigger = a; smaller = b;
        }else if(b.size > a.size){
            bigger = b; smaller = a;
        }else{
            return; // どちらも決定的に大きくないので何もしない
        }
        // 大きい方の半径の中に小さい方の中心が入っていれば食べられる、という簡易判定
        if(dist > bigger.radius) return;
        if(smaller.owner.isInvincible()) return; // スポーン直後の無敵中は食べられない

        bigger.size = Math.min(bigger.size + smaller.size, Constants.MAX_CELL_SIZE);
        smaller.destroy();

        Player enemy = smaller.owner;
        enemy.sum();
        if(!enemy.alive) bigger.owner.kills++;
    }
}