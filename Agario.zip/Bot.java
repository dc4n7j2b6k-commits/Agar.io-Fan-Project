import java.awt.*;
import java.awt.geom.*;
import java.util.*;
import java.util.List;
import java.util.stream.Collectors;

public class Bot extends Player{
    private final StringBuilder characters = new StringBuilder();

    private final BotAI ai = new BotAI(this);

    public Bot(Vector2D pos, long size, int teamId){
        super(pos, size, teamId);
        characters.append("あいうえおアイウエオかきくけこカキクケコ");
        characters.append("さしすせそサシスセソたちつてとタチツテト");
        characters.append("なにぬねのナニヌネノはひふへほハヒフヘホ");
        characters.append("まみむめもマミムメモやゆよヤユヨわをんワヲン");
        characters.append("らりるれろラリルレロぁぃぅぇぉァィゥェォゃゅょャュョっッー");
        characters.append("がぎぐげごガギグゲゴざじずぜぞザジズゼゾ");
        characters.append("だぢづでどダヂヅデドばびぶべぼバビブベボ");
        characters.append("ぱぴぷぺぽパピプペポヴ一二三四五六七八九十百千万");
        name = randomName();
    }
    public void update(double deltaTime, SpatialHashGrid spatialHash, Food[] foods){
        if(!alive) return;
        if(spawnInvincible > 0) spawnInvincible -= deltaTime;

        if(size > bestScore) bestScore = size;
        sum();

        Vector2D mouse = ai.decideMove(spatialHash);
        if(Float.isNaN(mouse.x) || Float.isNaN(mouse.y)) throw new IllegalArgumentException("->" + mouse);
        angle = (float)Math.atan2(mouse.y - pos.y, mouse.x - pos.x);
        boolean fireSplit = ai.thinkSplit(spatialHash, angle);
        splitCell(mouse.x, mouse.y, fireSplit);

        boolean fireThrow = ai.thinkThrowMass(spatialHash, angle);
        throwMass(mouse.x, mouse.y, fireThrow, foods);
        move(mouse.x, mouse.y);
    }
    // 名前を決める
    private String randomName(){
        int length = rand.nextInt(5) + 3;
        StringBuilder sb = new StringBuilder();
        for(int i=0;i<length;i++){
            char c = characters.toString().charAt(rand.nextInt(characters.toString().length()));
            sb.append(c);
        }
        return sb.toString();
    }
    public String toString(){
        return name;
    }
}
