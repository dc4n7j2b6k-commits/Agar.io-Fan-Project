import java.awt.*;
import java.awt.geom.*;
import java.util.*;
import java.util.List;

public class Cell extends Entity{
    private static final Font SCORE_FONT = new Font(Constants.FONT_NAME, Font.BOLD, 5);

    private static final Ellipse2D circle = new Ellipse2D.Float();

    public final Player owner;
    public float splitTimer = 0;
    public float decreaseTimer = 0;

    public Cell(Player owner){
        super(new Vector2D(0, 0));
        this.owner = owner;
        this.teamId = owner.teamId;
        bodyColor = owner.bodyColor;
        outlineColor = owner.outlineColor;
        alive = false;
        updateTargetZoom();
    }
    public Cell(Player owner, Vector2D pos, long size){
        super(pos.x, pos.y);
        this.owner = owner;
        this.teamId = owner.teamId;
        this.size = size;
        bodyColor = owner.bodyColor;
        outlineColor = owner.outlineColor;
        updateTargetZoom();
    }
    public void spawn(Vector2D pos, long size){
        this.pos.x = pos.x;
        this.pos.y = pos.y;
        this.vel.x = 0;
        this.vel.y = 0;
        this.size = size;
        bodyColor = owner.bodyColor;
        outlineColor = owner.outlineColor;
        this.splitTimer = Constants.SPLIT_COOLDOWN_SECONDS;
        this.alive = true;
    }
    public void destroy(){
        this.size = 0;
        this.alive = false;
    }
    public void eatFood(long size){
        this.size += size;
    }
    public void update(double deltaTime){
        updateTargetZoom();
        decreaseTimer += deltaTime;
        if(splitTimer > 0) splitTimer -= deltaTime;
        if(decreaseTimer >= 1.0f){
            if(size >= 100) size = (long)(size * 0.998);
            decreaseTimer = 0;
        }
        vel.scale(0.9f);
        pos.x = Math.max(radius, Math.min(pos.x + vel.x, Constants.MAP_WIDTH  - radius));
        pos.y = Math.max(radius, Math.min(pos.y + vel.y, Constants.MAP_HEIGHT - radius));
    }
    public void draw(Graphics2D g2d, Camera cam){
        float sx = cam.worldToScreenX(pos.x);
        float sy = cam.worldToScreenY(pos.y);
        float sr = radius * cam.zoom;

        float circleX = sx - sr;
        float circleY = sy - sr;
        float circleRadius = sr * 2;
        g2d.setColor(bodyColor);
        circle.setFrame(circleX, circleY, circleRadius, circleRadius);
        g2d.fill(circle);

        HUD.drawCenterFont(g2d, sx, sy, SCORE_FONT.deriveFont(sr * 0.35f), Color.WHITE, owner.name);
        String formatScore = NumberFormatter.formatSize(size);
        HUD.drawCenterFont(g2d, sx, sy + sr * 0.4f, SCORE_FONT.deriveFont(sr * 0.2f), Color.WHITE, formatScore);
    }
    public void move(float angle, float targetX, float targetY){
        if(size == 0) return;
        float dx = targetX - pos.x;
        float dy = targetY - pos.y;
        float distance = (float) Math.sqrt(dx * dx + dy * dy);
        if(distance < 1) return;

        float speedFactor = 1.0f;

        float dirX = (float)Math.cos(angle);
        float dirY = (float)Math.sin(angle);

        float resultSize = (float)Math.sqrt(size);
        vel.x += (dirX * 6.0f / resultSize) * speedFactor;
        vel.y += (dirY * 6.0f / resultSize) * speedFactor;
    }
    public long getSize(){
        return size;
    }
    public Color getBodyColor(){
        if(teamId >= 0){
            return TEAM_COLORS[teamId % TEAM_COLORS.length];
        }
        return getColor();
    }
    public Color getOutlineColor(){
        if(teamId >= 0){
            return TEAM_OUTLINES[teamId % TEAM_OUTLINES.length];
        }
        return getColor().darker();
    }
    public String toString(){
        return String.format("%s:%d:%s:%s", owner, size, pos, vel);
    }
}