import javax.swing.*;
import javax.swing.Timer;
import java.awt.*;
import java.awt.font.*;
import java.awt.event.*;
import java.awt.image.*;
import java.awt.geom.*;
import java.math.*;
import java.util.*;
import java.util.List;
import java.util.concurrent.*;
import java.io.File;
import javax.imageio.ImageIO;

public class AgarIOMenu extends JPanel implements ActionListener{
    private JTextField nickName = new JTextField("Player", 10);
    private JButton start = new JButton("Play!");
    private JComboBox<String> combo;
    public static final int PANEL_WIDTH = 1280, PANEL_HEIGHT = 720;
    private String[] mode = {"FFA", "2Teams", "3Teams", "4Teams"};
    private float timeColor = 0.0f;
    Timer timer = new Timer(16, this);
    public AgarIOMenu(CardLayout card, JPanel parent){
        setLayout(null);
        setPreferredSize(new Dimension(PANEL_WIDTH, PANEL_HEIGHT));
        combo = new JComboBox<>(mode);
        combo.setBounds(PANEL_WIDTH / 2 - 200, PANEL_HEIGHT / 2 - 75, 200, 40);
        combo.setFont(new Font("SansSerif", Font.BOLD, 25));
        combo.setMaximumRowCount(5);
        add(combo);
        start.setBounds(PANEL_WIDTH / 2 + 125, PANEL_HEIGHT / 2 - 25, 75, 50);
        start.setBackground(Color.CYAN);
        start.setBorderPainted(false);
        add(start);
        nickName.setBounds(PANEL_WIDTH / 2 - 200, PANEL_HEIGHT / 2 - 25, 400, 50);
        nickName.setFont(new Font("SansSerif", Font.PLAIN, 20));
        add(nickName);

        timer.start();
        start.addActionListener(e -> AgarIO.showMap());
    }
    public void paintComponent(Graphics g){
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        String gameTitle = "Agar.IO";
        g2.setColor(Color.getHSBColor((float)(timeColor / 10.0f), 1.0f, 1.0f));
        drawFont(g2, PANEL_WIDTH / 2, PANEL_HEIGHT / 4, new Font("Serif", Font.PLAIN, 100), gameTitle);
        g2.setColor(Color.BLACK);
        drawGlyph(g2, PANEL_WIDTH / 2, PANEL_HEIGHT / 4, new Font("Serif", Font.PLAIN, 100), gameTitle, false);
    }
    public void actionPerformed(ActionEvent e){
        timeColor = (timeColor + 0.01f) % 10.0f;
        repaint();
    }
    public String getNickName(){
        return nickName.getText();
    }
    public String getGameMode(){
        return (String) combo.getSelectedItem();
    }

    public void drawFont(Graphics2D g2, double x, double y, Font f, String text){
        FontMetrics font = g2.getFontMetrics(f);
        float text_x = font.stringWidth(text);
        float fx = (float)x - text_x / 2;
        float text_y = font.getHeight();
        float fy = (float)y + font.getAscent() - text_y / 2;
        g2.setFont(f);
        g2.drawString(text, fx, fy);
    }
    public void drawGlyph(Graphics2D g2, double x, double y, Font f, String text, boolean flg){
        FontMetrics font = g2.getFontMetrics(f);
        float text_x = font.stringWidth(text);
        float fx = (float)x - text_x / 2;
        float text_y = font.getHeight();
        float fy = (float)y + font.getAscent() - text_y / 2;
        g2.setFont(f);
        GlyphVector gv = f.createGlyphVector(g2.getFontRenderContext(), text);
        if(flg) g2.fill(gv.getOutline(fx, fy));
        else g2.draw(gv.getOutline(fx, fy));
    }
}