import java.awt.*;
import java.awt.geom.*;
import java.util.*;
import java.util.List;

public class Food extends Entity{

    private final Ellipse2D fillCircle = new Ellipse2D.Float();
    private float timer = 0f;
    public float invincibleTimer = 0f;
    public Food(Vector2D pos, Color color){
        super(pos);
        this.size = 1;
        setRadius();
        bodyColor = color == null ? getColor() : color;
    }
    public Food(float x, float y, Color color){
        this(new Vector2D(x, y), color);
    }
    public void setPosition(float x, float y, long size, Color color){
        pos.x = x;
        pos.y = y;
        this.size = size;
        bodyColor = color == null ? getColor() : color;
        alive = true;
        setRadius();
    }
    public void destroy(){
        pos.x = pos.y = 0;
        vel.x = vel.y = 0;
        size = 0;
        alive = false;
    }
    public void update(double deltaTime){
        if(invincibleTimer > 0) invincibleTimer -= deltaTime;
        if(vel.lengthSq() > 1){
            pos.add(vel);
            vel.scale(0.9f);
        }else{
            vel.x = vel.y = 0;
            timer += deltaTime;
            if(timer >= 60){
                timer = 0;
                if(size < 5){
                    size++;
                    setRadius();
                }
            }
        }
    }
    public void draw(Graphics2D g2d, Camera cam){
        float sx = cam.worldToScreenX(pos.x);
        float sy = cam.worldToScreenY(pos.y);
        float sr = radius * cam.zoom;

        g2d.setColor(bodyColor);
        fillCircle.setFrame(sx - sr, sy - sr, sr * 2, sr * 2);
        g2d.fill(fillCircle);
    }
}