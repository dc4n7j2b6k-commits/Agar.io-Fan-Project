public class Vector2D{
    public float x, y;

    public Vector2D(float x, float y){
        this.x = x;
        this.y = y;
    }
    public static Vector2D fromAngle(float radians){
        return new Vector2D(
            (float)Math.cos(radians),
            (float)Math.sin(radians)
        );
    }
    public Vector2D copy(){
        return new Vector2D(x, y);
    }
    public Vector2D add(Vector2D other){
        x += other.x;
        y += other.y;
        return this;
    }
    public Vector2D sub(Vector2D other){
        x -= other.x;
        y -= other.y;
        return this;
    }
    public Vector2D scale(float s){
        x *= s;
        y *= s;
        return this;
    }
    public float length(){
        return (float) Math.sqrt(x * x + y * y);
    }
    public float lengthSq(){
        return x * x + y * y;
    }
    public boolean equals(Vector2D other){
        return x == other.x && y == other.y;
    }
    public Vector2D normalize(){
        float len = length();
        if(len == 0){
            x = y = 0;
        }else{
            x /= len;
            y /= len;
        }
        return this;
    }
    public float distanceTo(Vector2D other){
        float dx = x - other.x;
        float dy = y - other.y;
        return (float) Math.sqrt(dx * dx + dy * dy);
    }

    public float angleTo(Vector2D other){
        return (float) Math.atan2(other.y - y, other.x - x);
    }

    public float dot(Vector2D other){
        return this.x * other.x + this.y * other.y;
    }
    public Vector2D limit(float max){
        float lenSq = lengthSq();
        if(lenSq > max * max){
            normalize().scale(max);
        }
        return this;
    }
    public Vector2D perp(){
        float perpX = -this.y;
        float perpY = this.x;
        this.x = perpX;
        this.y = perpY;
        return this;
    }
    public Vector2D rotate(double angle){
        float cos = (float)Math.cos(angle);
        float sin = (float)Math.sin(angle);
        x = x * cos - y * sin;
        y = x * sin + y * cos;
        return this;
    }
    public String toString(){
        return String.format("Vector2D[x=%f,y=%f]",x,y);
    }
}
