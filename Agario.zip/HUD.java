import java.awt.*;
import java.awt.font.*;
import java.awt.geom.*;
import java.util.*;
import java.util.List;
import java.util.stream.Collectors;

public class HUD{

    public void draw(Graphics2D g2d, Player player, Bot[] bots, long[] teamSize, boolean teamMode, int fps){
        drawRanking(g2d, player, bots, teamMode);
        if(teamMode) drawTeamPieChart(g2d, teamSize);
        drawCenterFont(g2d, 50, Constants.SCREEN_HEIGHT - 25, new Font("MONOSPACED", Font.BOLD, 20), Color.RED, fps + "FPS");
    }
    public void drawFont(Graphics2D g, int x, int y, Font f, String text){
        FontMetrics font = g.getFontMetrics(f);
        int text_x = font.stringWidth(text);
        int fx = x - text_x / 2;
        int text_y = font.getHeight();
        int fy = y + font.getAscent() - text_y / 2;
        g.setFont(f);
        g.drawString(text, fx, fy);
    }
    public static void drawCenterFont(Graphics2D g2d, float x, float y, Font f, Paint paint, String text){
        FontMetrics font = g2d.getFontMetrics(f);
        float text_x = font.stringWidth(text);
        float fx = x - text_x / 2;
        float text_y = font.getHeight();
        float fy = y + font.getAscent() - text_y / 2;
        g2d.setFont(f);
        g2d.setPaint(paint);
        g2d.drawString(text, fx, fy);
    }
    public static void drawGlyph(Graphics2D g2d, float x, float y, Font f, Paint paint, String text, BasicStroke bs){
        FontMetrics font = g2d.getFontMetrics(f);
        float text_x = font.stringWidth(text);
        float fx = x - text_x / 2;
        float text_y = font.getHeight();
        float fy = y + font.getAscent() - text_y / 2;
        g2d.setFont(f);
        g2d.setPaint(paint);
        GlyphVector gv = f.createGlyphVector(g2d.getFontRenderContext(), text);
        g2d.setStroke(bs);
        g2d.draw(gv.getOutline(fx, fy));
        g2d.setStroke(new BasicStroke(1.0f));
    }
    private void drawRanking(Graphics2D g2d, Player player, Bot[] bots, boolean teamMode){

        int x = teamMode ? 20 : Constants.SCREEN_WIDTH - 260, y = 20, width = 240, height = 250;

        g2d.setColor(new Color(0, 0, 0, 100));
        g2d.fillRect(x, y, width, height + 50);
        drawCenterFont(g2d, x + width / 2, y + 25, new Font(Constants.FONT_NAME, Font.BOLD, 35), Color.WHITE, "Leaderboard");

        List<Player> list = buildRanking(player, bots);
        if(list.size() == 0) return;
        list.sort(Comparator.comparingLong(Player::getSize).reversed());

        y += 55;

        for(int i = 0; i < Math.min(10, list.size()); i++){
            Player p = list.get(i);
            int index = i + 1;
            Color color = teamMode ? p.bodyColor : Color.WHITE;
            drawCenterFont(g2d, x + width / 2, y, new Font(Constants.FONT_NAME, Font.BOLD, 20), color, index + ". " + p.name);
            y += 25;
        }
    }
    private List<Player> buildRanking(Player player, Bot[] bots){
        List<Player> entry = new ArrayList<>();
        if(player.alive) entry.add(player);
        for(Bot bot : bots) if(bot.alive) entry.add(bot);
        return entry;
    }
    // チーム
    private void drawTeamPieChart(Graphics2D g2d, long[] teamSize){
        long total = teamSize[0] + teamSize[1] + teamSize[2] + teamSize[3];
        if(total == 0) return;
        float x = Constants.SCREEN_WIDTH - 260, y = 20, width = 240, height = 220;

        g2d.setColor(new Color(0, 0, 0, 100));
        g2d.fill(new Rectangle2D.Float(x, y, width, height + 50));
        drawCenterFont(g2d, x + width / 2, y + 25, new Font(Constants.FONT_NAME, Font.BOLD, 35), Color.WHITE, "Leaderboard");
        float startAngle = 0;
        x += 20; y += 50; width = height = 200;
        Color[] colors = new Color[]{Color.BLUE, Color.GREEN, Color.RED, Color.YELLOW};
        for(int i = 0; i < teamSize.length; i++){
            float angle = (float)((teamSize[i] * 360) / total);
            g2d.setColor(colors[i]);
            g2d.fill(new Arc2D.Float(x, y, width, height, startAngle, angle, Arc2D.PIE));
            startAngle += angle;
        }
    }
    // ── GAME OVER ────────────────────────────────────────────────────────────
    public void drawGameOver(Graphics2D g2d, Player player){
        // 半透明オーバーレイ（薄め—スペクテート中もゲームが見える）
        g2d.setColor(new Color(0, 0, 0, 100));
        g2d.fillRect(0, 0, Constants.SCREEN_WIDTH,Constants.SCREEN_HEIGHT);

        drawCenterFont(g2d, Constants.SCREEN_WIDTH / 2, Constants.SCREEN_HEIGHT / 8, new Font("Serif", Font.ITALIC, 100), Color.RED, "Game Over");
        drawGlyph(g2d, Constants.SCREEN_WIDTH / 2, Constants.SCREEN_HEIGHT / 8, new Font("Serif", Font.ITALIC, 100), Color.BLACK, "Game Over", new BasicStroke(5.0f));
        drawCenterFont(g2d, Constants.SCREEN_WIDTH / 2, Constants.SCREEN_HEIGHT / 4, new Font("DIALOG", Font.PLAIN, 25), Color.WHITE, "ベストスコア："+NumberFormatter.formatSize(player.bestScore));
        drawCenterFont(g2d, Constants.SCREEN_WIDTH / 2, Constants.SCREEN_HEIGHT / 4 + 25, new Font("DIALOG", Font.PLAIN, 25), Color.WHITE, "キル数💀："+player.kills);
    }
    // ── ユーティリティ ───────────────────────────────────────────────────────
    private String truncate(String s, int max){ return s.length()>max?s.substring(0,max)+"…":s; }
}
