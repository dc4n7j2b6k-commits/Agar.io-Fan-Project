import javax.swing.*;
import javax.swing.Timer;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.awt.geom.*;
import java.math.*;
import java.util.*;
import java.util.List;
import java.util.concurrent.*;
import java.io.File;
import javax.imageio.ImageIO;

public class AgarIO extends JFrame{
    private static CardLayout card = new CardLayout();
    private static JPanel cardPanel = new JPanel(card);
    private static AgarIOMap map;
    private static AgarIOMenu menu;

    public AgarIO(){
        setTitle("Agar.io fanmade");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        cardPanel.setPreferredSize(new Dimension(Constants.SCREEN_WIDTH, Constants.SCREEN_HEIGHT));
        map = new AgarIOMap(card, cardPanel);
        menu = new AgarIOMenu(card, cardPanel);
        cardPanel.setLayout(card);
        cardPanel.add(menu, "menu");
        cardPanel.add(map, "map");
        add(cardPanel);
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }
    public static void showMap(){
        map.requestFocusInWindow();
        map.onShow(menu.getGameMode(), menu.getNickName());
        card.show(cardPanel, "map");
    }
    public static void main(String[] args){
        SwingUtilities.invokeLater(() -> {
            new AgarIO();
        });
    }
}