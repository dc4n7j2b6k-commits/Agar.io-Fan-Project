import java.util.*;

public class BotAI{
    private final Bot self;

    private final Random rand = new Random();
    private final boolean isTeam;

    public BotAI(Bot self){
        this.self = self;
        this.isTeam = self.teamId >= 0;
    }
    public Vector2D decideMove(SpatialHashGrid spatialHash){
        float minDistSq = Float.MAX_VALUE;
        float range = self.viewRangeWorld;

        Vector2D direction = new Vector2D(0, 0);

        List<Entity> nearbyEntitys = spatialHash.getNearby(self.pos.x, self.pos.y, range);

        for(Cell myCell : self.cells){
            if(!myCell.alive) continue;
            Entity closest = null;
            for(Entity entity : nearbyEntitys){
                if(!entity.alive) continue;
                if(entity instanceof Cell cell && cell.owner == self) continue;

                float dx = entity.pos.x - myCell.pos.x;
                float dy = entity.pos.y - myCell.pos.y;
                float distSq = dx * dx + dy * dy;
                if(distSq == 0) continue;
                float dist = (float)Math.sqrt(distSq);
                if(entity instanceof Food food){
                    if(distSq < minDistSq){
                        minDistSq = distSq;
                        closest = food;
                    }
                }else if(entity instanceof Cell cell){
                    if(isTeam && cell.teamId == self.teamId) continue;

                    minDistSq = distSq;
                    closest = cell;
                }
            }

            if(closest != null){
                float dx = closest.pos.x - myCell.pos.x;
                float dy = closest.pos.y - myCell.pos.y;
                float d = (float)Math.sqrt(dx * dx + dy * dy);
                if(d > 0 && myCell.size > 0 && closest.size > 0){
                    float sizeRatio = (float) closest.size / myCell.size;
                    float minus = sizeRatio >= 1.0f ? -sizeRatio : 1.0f / sizeRatio;

                    if(Float.isNaN(minus) || Float.isInfinite(minus)) throw new IllegalArgumentException("->" + minus +"-"+ sizeRatio + " <- " + closest.size +"/"+ myCell.size);

                    direction.x += (dx * minus) / d;
                    direction.y += (dy * minus) / d;
                }
            }
        }
        float targetDistance = 500f; 

        return new Vector2D(
            self.pos.x + direction.x * targetDistance,
            self.pos.y + direction.y * targetDistance
        );
    }
    public boolean thinkSplit(SpatialHashGrid spatialHash, float angle){ // このangleは移動方向であり、分裂で飛ばす方向でもある。
        float range = self.viewRangeWorld;
        List<Entity> nearbyEntitys = spatialHash.getNearby(self.pos.x, self.pos.y, range);

        Entity closestThreat = null;
        Entity closestTarget = null;
        Cell closestMyCell = null;
        float minThreatDistSq = Float.MAX_VALUE;
        float minTargetDistSq = Float.MAX_VALUE;
        float maxMyCellDistSq = Float.MAX_VALUE;

        for(Cell myCell : self.cells){
            if(!myCell.alive) continue;

            for(Entity entity : nearbyEntitys){
                if(!entity.alive) continue;
                if(entity instanceof Cell cell && cell.owner == self) continue;

                float dx = entity.pos.x - myCell.pos.x;
                float dy = entity.pos.y - myCell.pos.y;
                float distSq = dx * dx + dy * dy;
                if(entity instanceof Cell enemyCell){
                    if(enemyCell.size > myCell.size * 1.3f){
                        if(distSq < minThreatDistSq){
                            minThreatDistSq = distSq;
                            closestThreat = enemyCell;
                            maxMyCellDistSq = distSq;
                            closestMyCell = myCell;
                        }
                    }else if((myCell.size / 2.0f) >= enemyCell.size * 1.3f){
                        if(distSq < minTargetDistSq){
                            minTargetDistSq = distSq;
                            closestTarget = enemyCell;
                            maxMyCellDistSq = distSq;
                            closestMyCell = myCell;
                        }
                    }
                }
            }
        }
        if(closestThreat != null){
            float dangerDist = 150.0f;
            if(minThreatDistSq < dangerDist * dangerDist){
                return true;
            }
        }
        if(closestTarget != null){
            // 分裂の射程圏内（ダッシュ距離）にあるか
            float splitRange = closestMyCell.radius * 4; 
            if(minTargetDistSq < splitRange * splitRange){
                return true;
            }
        }
        return false;
    }
    public boolean thinkThrowMass(SpatialHashGrid spatialHash, float angle){
        return false;
    }
}